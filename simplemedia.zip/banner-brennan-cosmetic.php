<!-- banner -->
<div class="banner background-c-teal1">
	<!-- banner__wrap -->
	<div class="banner__wrap container">
		<div class="banner__wrap-nav works">
			<div class="banner__item">
				<div class="banner__title font-f-simplifica font-c-white">Dr. Brennan Cosmetic Center</div>
			</div>
		</div>
	</div>
	<!-- banner__wrap -->
	<div class="banner__bg" style="background: url(dist/img/dr_brennan_01.jpg) no-repeat center / cover"></div>
	<!-- banner__scroll -->
	<div class="banner__scroll">
		<svg class="icon icon--l" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
			<use class="icon__white" xlink:href="#ic-scroll" />
		</svg>
	</div>
	<!-- banner__scroll -->
</div>
<!-- banner -->