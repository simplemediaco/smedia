<?php require_once('header.php'); ?>
<?php require_once('navigation.php'); ?>
<?php require_once('banner-works.php'); ?>
	
	<!-- works -->
	<div class="padding-t-100 background-c-grey4">
		<div class="container margin-b-50">
			<div class="row">
				<div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-12 col-md-offset-0 heading font-f-simplifica">Our Works</div>
			</div>
		</div>
		<div class="image-grid js">
			<div class="image-grid__item image-grid__item-sizer"></div>
			<a href="http://smstaging.net/simplemedia-new/works-agency-blazr.php" class="image-grid__item aspect-ratio-2-4" style="background: url(dist/img/agency_blazr_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-azzimato.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/azzimato_03.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-cibo-divino.php" class="image-grid__item aspect-ratio-2-4" style="background: url(dist/img/cibo_divino_04.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-brennan-cosmetic.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/dr_brennan_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-episcale.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/episcale_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-kintz-group.php" class="image-grid__item aspect-ratio-2-4" style="background: url(dist/img/kintznow_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-northern-lights.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/northern_lights_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-email-experience.php" class="image-grid__item image-grid__item--full aspect-ratio-2-1" style="background: url(dist/img/ecc_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-overly.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/overly_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-sally-evans.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/sally_evans_02.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-my-directives.php" class="image-grid__item image-grid__item--full aspect-ratio-2-1" style="background: url(dist/img/my_directive_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-adestra.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/adestra_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-cantu.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/cantu_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-cry-havoc.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/cry_havoc_01.jpg) no-repeat center / cover"></a>
			<a href="http://smstaging.net/simplemedia-new/works-parking-day.php" class="image-grid__item aspect-ratio-1-1" style="background: url(dist/img/parking_day_01.jpg) no-repeat center / cover"></a>
		</div>
	</div>
	<!-- works -->

	<div class="padding-t-100 padding-b-100">
		<div class="container">
			<div class="margin-b-30 center-text">
				<img src="dist/img/illustration-testimonial.svg">
			</div>
			<div class="margin-b-30 heading font-f-simplifica center-text">Choose a plan that’s right for you</div>
			<div class="center-text">
				<a href="#" class="button button--b-teal1 button--c-teal1 font-f-sansation">View Pricing</a>
			</div>
		</div>
	</div>

<?php require_once('footer.php'); ?>