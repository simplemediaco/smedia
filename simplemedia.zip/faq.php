<?php require_once('header.php'); ?>
<?php require_once('navigation.php'); ?>
<?php require_once('banner-faq.php'); ?>

	<div class="padding-t-100 padding-b-100 background-c-grey4">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 accordion js">
					<div class="background-c-white padding-20 margin-b-20">
						<div class="accordion__title font-f-sansation open font-c-teal1">Improve Your Business Cards And Enhance Your Sales</div>
						<div class="accordion__content-wrap">
							<div class="accordion__content clearfix">
								<p>Marketers/advertisers usually focus their efforts on the people responsible for making the purchase. In many cases, this is an effective approach but in other cases it can make for a totally useless marketing campaign.</p>
							</div>
						</div>
					</div>
					<div class="background-c-white padding-20 margin-b-20">
						<div class="accordion__title font-f-sansation font-c-teal1">Improve Your Business Cards And Enhance Your Sales</div>
						<div class="accordion__content-wrap">
							<div class="accordion__content clearfix">
								<p>Marketers/advertisers usually focus their efforts on the people responsible for making the purchase. In many cases, this is an effective approach but in other cases it can make for a totally useless marketing campaign.</p>
								<p>Marketers/advertisers usually focus their efforts on the people responsible for making the purchase. In many cases, this is an effective approach but in other cases it can make for a totally useless marketing campaign.</p>
							</div>
						</div>
					</div>
					<div class="background-c-white padding-20 margin-b-20">
						<div class="accordion__title font-f-sansation font-c-teal1">Improve Your Business Cards And Enhance Your Sales</div>
						<div class="accordion__content-wrap">
							<div class="accordion__content clearfix">
								<p>Marketers/advertisers usually focus their efforts on the people responsible for making the purchase. In many cases, this is an effective approach but in other cases it can make for a totally useless marketing campaign.</p>
							</div>
						</div>
					</div>
					<div class="background-c-white padding-20 margin-b-20">
						<div class="accordion__title font-f-sansation font-c-teal1">Improve Your Business Cards And Enhance Your Sales</div>
						<div class="accordion__content-wrap">
							<div class="accordion__content clearfix">
								<p>Marketers/advertisers usually focus their efforts on the people responsible for making the purchase. In many cases, this is an effective approach but in other cases it can make for a totally useless marketing campaign.</p>
							</div>
						</div>
					</div>
					<div class="background-c-white padding-20 margin-b-20">
						<div class="accordion__title font-f-sansation font-c-teal1">Improve Your Business Cards And Enhance Your Sales</div>
						<div class="accordion__content-wrap">
							<div class="accordion__content clearfix">
								<p>Marketers/advertisers usually focus their efforts on the people responsible for making the purchase. In many cases, this is an effective approach but in other cases it can make for a totally useless marketing campaign.</p>
								<p>Marketers/advertisers usually focus their efforts on the people responsible for making the purchase. In many cases, this is an effective approach but in other cases it can make for a totally useless marketing campaign.</p>
							</div>
						</div>
					</div>
					<div class="background-c-white padding-20 margin-b-20">
						<div class="accordion__title font-f-sansation font-c-teal1">Improve Your Business Cards And Enhance Your Sales</div>
						<div class="accordion__content-wrap">
							<div class="accordion__content clearfix">
								<p>Marketers/advertisers usually focus their efforts on the people responsible for making the purchase. In many cases, this is an effective approach but in other cases it can make for a totally useless marketing campaign.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php require_once('footer.php'); ?>