<?php require_once('header.php'); ?>
<?php require_once('navigation-light.php'); ?>

	<!-- account info -->
	<div class="padding-t-100 padding-b-100 background-c-grey4">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-md-8 col-md-offset-2">
					<div class="heading font-f-simplifica margin-b-20">This is privacy policy</div>
					<div class="font-f-sansation font-c-teal1">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
				</div>
			</div>
		</div>
	</div>
	<!-- account info -->

<?php require_once('footer.php'); ?>